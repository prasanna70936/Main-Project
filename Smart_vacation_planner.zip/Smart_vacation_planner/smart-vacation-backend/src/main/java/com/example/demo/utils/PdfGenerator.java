package com.example.demo.utils;

import java.io.OutputStream;

import com.example.demo.dto.TripPlanResponse;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.List;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import org.springframework.stereotype.Component;

@Component 

/**
 * Generates a PDF itinerary for a trip plan using iText.
 */
public class PdfGenerator {

    /**
     * Generates a PDF document of the trip itinerary.
     *
     * @param plan the trip plan details
     * @param outputStream the output stream to write the PDF to
     */
    public void generateItineraryPdf(TripPlanResponse plan, OutputStream outputStream) {
        try {
            PdfWriter writer = new PdfWriter(outputStream);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            // Create a bold font
            PdfFont boldFont = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);

            // Title with bold font
            Paragraph title = new Paragraph(PdfConstants.TITLE)
                    .setFontSize(18)
                    .setFont(boldFont) // this replaces .setBold()
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(title);

            document.add(new Paragraph("\n"));

            // General Info
            document.add(new Paragraph("Trip ID: " + plan.getTripId()));
            document.add(new Paragraph("Estimated Budget: $" + plan.getEstimatedBudget()));

            // Weather
            document.add(new Paragraph("\nWeather Forecast:"));
            document.add(new Paragraph(plan.getWeather()));

            // Itinerary
            document.add(new Paragraph("\nDay-wise Itinerary:"));
            List itineraryList = new List();
            plan.getDayWiseItinerary().forEach(day -> itineraryList.add(day));
            document.add(itineraryList);

            // Places
            document.add(new Paragraph("\nPlanned Places:"));
            List placesList = new List();
            plan.getPlaces().forEach(place -> placesList.add(place));
            document.add(placesList);

            // Hotels
            if (plan.getHotelOptions() != null && !plan.getHotelOptions().isEmpty()) {
                document.add(new Paragraph("\nHotel Options:"));
                List hotelList = new List();
                plan.getHotelOptions().forEach(hotel -> hotelList.add(hotel));
                document.add(hotelList);
            }

            // Footer
            document.add(new Paragraph("\n" + PdfConstants.FOOTER).setTextAlignment(TextAlignment.CENTER));

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate PDF: " + e.getMessage(), e);
        }
    }
}
