package com.example.demo.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;

@Service
public class EmailService {

    @Value("${sendgrid.api.key}")
    private String sendGridApiKey;  // Your SendGrid API key

    @Value("${sendgrid.from.email}")
    private String fromEmail;       // Must match your verified SendGrid sender

    /**
     * Sends an email using SendGrid. Replies will be sent to the 'replyTo' address.
     *
     * @param to      Recipient email address
     * @param subject Email subject
     * @param text    Email body (plain text)
     * @param replyTo Optional reply-to address (e.g., user's email)
     */
    public void sendEmail(String to, String subject, String text, String replyTo) throws IOException {
        Email from = new Email(fromEmail);
        Email toEmail = new Email(to);
        Content content = new Content("text/plain", text);

        Mail mail = new Mail(from, subject, toEmail, content);

        // IMPORTANT: Set reply-to to your user's email (where you'd like replies sent, if any)
        if (replyTo != null && !replyTo.isBlank()) {
            mail.setReplyTo(new Email(replyTo));
        }

        SendGrid sg = new SendGrid(sendGridApiKey);
        Request request = new Request();
        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            Response response = sg.api(request);
            if (response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
                System.out.println("✅ Email sent successfully to " + to);
            } else {
                System.err.println("❌ Failed to send email. Status: " + response.getStatusCode());
                System.err.println("Response body: " + response.getBody());
            }
        } catch (IOException ex) {
            System.err.println("❌ Error sending email: " + ex.getMessage());
            throw ex;
        }
    }

    // Overloaded convenience method when replyTo isn't needed
    public void sendEmail(String to, String subject, String text) throws IOException {
        sendEmail(to, subject, text, null);
    }
}
