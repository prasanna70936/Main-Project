package com.example.demo.service;

import com.example.demo.dto.SignupRequest;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public User signup(SignupRequest request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword("{noop}" + request.getPassword());

        // Set role or default to ROLE_USER
        user.setRole(request.getRole() != null && !request.getRole().isBlank()
            ? request.getRole()
            : "ROLE_USER"
        );

        return userRepository.save(user);
    }

    public boolean login(String email, String password) {
        return userRepository.findByEmail(email)
            .map(u -> ("{noop}" + password).equals(u.getPassword()))
            .orElse(false);
    }
}
