package com.example.demo.dto;

import java.util.List;

/**
 * Response body for returning planned trip details.
 */
public class TripPlanResponse {

    private Long tripId;
    private List<String> places;
    private double estimatedBudget;
    private List<String> dayWiseItinerary;
    private String weather;               // e.g., "Clear sky, 22°C"
    private List<String> hotelOptions;    // optional, can be null or empty

    // --- Getters & Setters ---
    public Long getTripId() { return tripId; }
    public void setTripId(Long tripId) { this.tripId = tripId; }

    public List<String> getPlaces() { return places; }
    public void setPlaces(List<String> places) { this.places = places; }

    public double getEstimatedBudget() { return estimatedBudget; }
    public void setEstimatedBudget(double estimatedBudget) { this.estimatedBudget = estimatedBudget; }

    public List<String> getDayWiseItinerary() { return dayWiseItinerary; }
    public void setDayWiseItinerary(List<String> dayWiseItinerary) { this.dayWiseItinerary = dayWiseItinerary; }

    public String getWeather() { return weather; }
    public void setWeather(String weather) { this.weather = weather; }

    public List<String> getHotelOptions() { return hotelOptions; }
    public void setHotelOptions(List<String> hotelOptions) { this.hotelOptions = hotelOptions; }
}
