package com.example.demo.dto;

import java.time.LocalDate;
import java.util.List;

/**
 * Request body for planning a new trip.
 */
public class TripRequest {

    private Long userId;
    private String userEmail;             // For sending confirmation emails
    private LocalDate startDate;
    private LocalDate endDate;
    private int numPeople;
    private double estimatedBudget;
    private List<String> places;          // list of places or cities

    // --- Getters & Setters ---
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public int getNumPeople() { return numPeople; }
    public void setNumPeople(int numPeople) { this.numPeople = numPeople; }

    public double getEstimatedBudget() { return estimatedBudget; }
    public void setEstimatedBudget(double estimatedBudget) { this.estimatedBudget = estimatedBudget; }

    public List<String> getPlaces() { return places; }
    public void setPlaces(List<String> places) { this.places = places; }
}
