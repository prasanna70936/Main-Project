package com.example.demo.model;

import jakarta.persistence.*;

/**
 * Represents a destination/location included in a trip or suggested to users.
 */
@Entity
@Table(name = "destinations")
public class Destination {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;           // ✅ NEW FIELD: e.g., "Paris, France"

    private String city;           // e.g., "Paris"
    private String country;        // e.g., "France"
    private String description;    // optional details about the destination
    private String imageUrl;       // optional URL for destination image

    // Optional: average estimated daily cost or rating
    private Double estimatedDailyBudget;

    // --- Getters & Setters ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }          // ✅ Getter
    public void setName(String name) { this.name = name; }  // ✅ Setter

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public Double getEstimatedDailyBudget() { return estimatedDailyBudget; }
    public void setEstimatedDailyBudget(Double estimatedDailyBudget) { this.estimatedDailyBudget = estimatedDailyBudget; }
}
