package com.example.demo.exception;

/**
 * Thrown when a requested resource (User, Trip, etc.) cannot be found.
 */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
