package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

import com.stripe.Stripe;
import com.stripe.model.Charge;
import com.stripe.model.PaymentIntent;
import com.stripe.model.Refund;
import com.stripe.param.PaymentIntentCreateParams;
import com.stripe.param.RefundCreateParams;
import com.stripe.param.ChargeListParams;

@Service
public class StripeService {

    @Value("${stripe.secret.key}")
    private String secretKey;

    public PaymentIntent createPaymentIntent(double amountInRupees) throws Exception {
        Stripe.apiKey = secretKey;

        PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
            .setAmount((long) (amountInRupees * 100)) // Convert ₹ to paise
            .setCurrency("inr")
            .build();

        return PaymentIntent.create(params);
    }

    public Refund createRefund(String paymentIntentId) throws Exception {
        Stripe.apiKey = secretKey;

        ChargeListParams chargeParams = ChargeListParams.builder()
            .setPaymentIntent(paymentIntentId)
            .setLimit(1L)
            .build();

        List<Charge> charges = Charge.list(chargeParams).getData();

        if (charges.isEmpty()) {
            throw new IllegalStateException("No charges found for PaymentIntent ID: " + paymentIntentId);
        }

        String chargeId = charges.get(0).getId();

        RefundCreateParams refundParams = RefundCreateParams.builder()
            .setCharge(chargeId)
            .build();

        return Refund.create(refundParams);
    }
}
