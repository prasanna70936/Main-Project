package com.example.demo.utils;

/**
 * Constants for PDF generation: titles, fonts, colors, etc.
 */
public class PdfConstants {

    public static final String TITLE = "Smart Vacation Planner - Trip Itinerary";
    public static final String FOOTER = "Thank you for using Smart Vacation Planner!";
    public static final String FONT_FAMILY = "Helvetica";

    private PdfConstants() {
        // Utility class; prevent instantiation
    }
}
