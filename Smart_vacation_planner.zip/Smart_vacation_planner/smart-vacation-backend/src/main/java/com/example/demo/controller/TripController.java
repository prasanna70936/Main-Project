package com.example.demo.controller;

import com.example.demo.dto.TripPlanResponse;
import com.example.demo.dto.TripRequest;
import com.example.demo.service.TripService;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/trips")
@CrossOrigin(origins = "http://localhost:3000")
public class TripController {

    @Autowired
    private TripService tripService;

    /**
     * Creates a new trip plan, saves it, triggers email confirmation, and returns itinerary info.
     */
    @PostMapping("/plan")
    public ResponseEntity<TripPlanResponse> planTrip(@RequestBody TripRequest request) {
        try {
            TripPlanResponse response = tripService.planTrip(request);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }

    /**
     * Returns trip history for a given user ID.
     */
    @GetMapping("/history/{userId}")
    public ResponseEntity<List<TripPlanResponse>> getTripHistory(@PathVariable Long userId) {
        try {
            List<TripPlanResponse> history = tripService.getTripHistory(userId);
            return ResponseEntity.ok(history);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }

    /**
     * Generates and returns a PDF itinerary based on the provided TripPlanResponse.
     */
    @PostMapping("/download-pdf")
    public void downloadItineraryAsPdf(
            @RequestBody TripPlanResponse plan,
            HttpServletResponse response
    ) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=itinerary.pdf");
        tripService.generatePdf(plan, response.getOutputStream());
    }
}
