package com.example.demo.repository;

import com.example.demo.model.Destination;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

/**
 * Repository to manage CRUD operations for Destination entities.
 */
public interface DestinationRepository extends JpaRepository<Destination, Long> {

    /**
     * Finds a destination by its name (case-sensitive by default).
     *
     * @param name the name of the destination
     * @return an Optional containing the destination if found
     */
	@Query("SELECT d FROM Destination d WHERE LOWER(d.name) = LOWER(:name)")
    Optional<Destination> findByNameIgnoreCase(@Param("name") String name);

}
