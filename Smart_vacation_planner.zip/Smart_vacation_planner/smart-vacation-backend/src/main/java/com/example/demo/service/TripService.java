package com.example.demo.service;

import com.example.demo.dto.TripPlanResponse;
import com.example.demo.dto.TripRequest;
import com.example.demo.model.Destination;
import com.example.demo.model.Trip;
import com.example.demo.model.User;
import com.example.demo.repository.DestinationRepository;
import com.example.demo.repository.TripRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.utils.PdfGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TripService {

    @Autowired private TripRepository tripRepository;
    @Autowired private DestinationRepository destinationRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private PdfGenerator pdfGenerator;
    @Autowired private EmailService emailService;
    @Autowired private WeatherService weatherService;

    /**
     * Plans a trip, saves it, sends confirmation email, and returns the plan response.
     */
    public TripPlanResponse planTrip(TripRequest request) throws IOException {
        // 1. Validate request
        if (request.getPlaces() == null || request.getPlaces().isEmpty())
            throw new IllegalArgumentException("TripRequest must include at least one place.");
        if (request.getUserId() == null || request.getUserEmail() == null || request.getUserEmail().isBlank())
            throw new IllegalArgumentException("TripRequest must include userId and userEmail.");

        // 2. Retrieve user and destinations
        User user = userRepository.findById(request.getUserId())
            .orElseThrow(() -> new RuntimeException("User not found: " + request.getUserId()));
        List<Destination> destinations = request.getPlaces().stream()
            .map(name -> destinationRepository.findByNameIgnoreCase(name)
                .orElseThrow(() -> new RuntimeException("Destination not found: " + name)))
            .collect(Collectors.toList());

        // 3. Save trip
        Trip trip = new Trip();
        trip.setUser(user);
        trip.setStartDate(request.getStartDate());
        trip.setEndDate(request.getEndDate());
        trip.setDestinations(destinations);
        trip.setNumPeople(request.getNumPeople());
        trip.setEstimatedBudget(request.getEstimatedBudget());
        tripRepository.save(trip);

        // 4. Get weather for first place
        String weatherSummary = weatherService.getCurrentWeather(destinations.get(0).getName());

        // 5. Build response
        TripPlanResponse response = new TripPlanResponse();
        response.setTripId(trip.getId());
        response.setPlaces(destinations.stream().map(Destination::getName).collect(Collectors.toList()));
        response.setEstimatedBudget(trip.getEstimatedBudget());
        response.setWeather(weatherSummary);
        response.setDayWiseItinerary(List.of(
            "Day 1: Visit " + destinations.get(0).getName(),
            destinations.size() > 1
                ? "Day 2: Explore " + destinations.get(1).getName()
                : "Day 2: Free day"
        ));

        // 6. Send confirmation email with Reply-To set to user
        String subject = "Your Smart Vacation Planner Itinerary";
        String body = String.format(
            "Hi %s,%n%nThank you for planning your trip!%n%n" +
            "Trip Summary:%nEstimated Budget: %.2f%nPlaces: %s%nWeather in %s: %s%n%n" +
            "Enjoy your vacation!",
            user.getName(),
            response.getEstimatedBudget(),
            String.join(", ", response.getPlaces()),
            destinations.get(0).getName(),
            weatherSummary
        );

        emailService.sendEmail(
            request.getUserEmail(),  // recipient
            subject,
            body,
            request.getUserEmail()   // Reply-To set to the user’s own email
        );

        return response;
    }

    /**
     * Retrieves all trip histories for a given user.
     */
    public List<TripPlanResponse> getTripHistory(Long userId) {
        return tripRepository.findByUserId(userId).stream().map(trip -> {
            List<String> places = trip.getDestinations().stream()
                                             .map(Destination::getName)
                                             .collect(Collectors.toList());
            String weather = weatherService.getCurrentWeather(places.get(0));

            TripPlanResponse r = new TripPlanResponse();
            r.setTripId(trip.getId());
            r.setPlaces(places);
            r.setEstimatedBudget(trip.getEstimatedBudget());
            r.setWeather(weather);
            r.setDayWiseItinerary(List.of(
                "Day 1: Visit " + places.get(0),
                places.size() > 1 ? "Day 2: Explore " + places.get(1) : "Day 2: Free day"
            ));
            return r;
        }).collect(Collectors.toList());
    }

    /**
     * Generates a PDF itinerary into the provided OutputStream.
     */
    public void generatePdf(TripPlanResponse plan, OutputStream out) {
        pdfGenerator.generateItineraryPdf(plan, out);
    }
}
