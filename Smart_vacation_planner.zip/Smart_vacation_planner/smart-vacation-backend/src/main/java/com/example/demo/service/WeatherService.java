package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

/**
 * Fetches weather forecasts for a given location using a third-party API.
 */
@Service
public class WeatherService {

    // ✅ Read API key dynamically from application.properties
    @Value("${weather.api.key}")
    private String apiKey;

    private static final String API_URL = "https://api.openweathermap.org/data/2.5/weather";

    private final RestTemplate restTemplate = new RestTemplate();

    /**
     * Gets current weather description for a city.
     * @param city name of the city (e.g., "Paris")
     * @return weather summary string (e.g., "Clear sky, 22°C")
     */
    public String getCurrentWeather(String city) {
        String url = UriComponentsBuilder.fromHttpUrl(API_URL)
                .queryParam("q", city)
                .queryParam("appid", apiKey) // use the injected API key here
                .queryParam("units", "metric")
                .toUriString();

        Map<String, Object> response = restTemplate.getForObject(url, Map.class);

        if (response != null && response.containsKey("weather") && response.containsKey("main")) {
            Map<String, Object> main = (Map<String, Object>) response.get("main");
            Double temp = (Double) main.get("temp");

            Map<String, Object> weather = ((java.util.List<Map<String, Object>>) response.get("weather")).get(0);
            String description = (String) weather.get("description");

            return description + ", " + temp + "°C";
        }
        return "Weather data unavailable";
    }
}
