package com.example.demo.controller;

import com.example.demo.service.StripeService;
import com.stripe.model.PaymentIntent;
import com.stripe.model.Refund;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/stripe")
public class StripeController {

    @Autowired
    private StripeService stripeService;

    @PostMapping("/make-payment")
    public ResponseEntity<?> createPayment(@RequestParam double amount) {
        try {
            PaymentIntent paymentIntent = stripeService.createPaymentIntent(amount);

            Map<String, Object> response = new HashMap<>();
            response.put("paymentId", paymentIntent.getId());
            response.put("amount", paymentIntent.getAmount());
            response.put("currency", paymentIntent.getCurrency());
            response.put("clientSecret", paymentIntent.getClientSecret());
            response.put("status", paymentIntent.getStatus());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }

    @PostMapping("/refund")
    public ResponseEntity<?> refundPayment(@RequestParam String paymentIntentId) {
        try {
            Refund refund = stripeService.createRefund(paymentIntentId);

            Map<String, Object> response = new HashMap<>();
            response.put("refundId", refund.getId());
            response.put("status", refund.getStatus());
            response.put("amountRefunded", refund.getAmount());
            response.put("currency", refund.getCurrency());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }
}
