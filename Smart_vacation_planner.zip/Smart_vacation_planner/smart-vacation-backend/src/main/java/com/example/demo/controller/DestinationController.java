package com.example.demo.controller;

import com.example.demo.model.Destination;
import com.example.demo.repository.DestinationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Destination entities.
 */
@RestController
@RequestMapping("/api/destinations")
public class DestinationController {

    @Autowired
    private DestinationRepository destinationRepository;

    /**
     * Get all destinations.
     */
    @GetMapping
    public List<Destination> getAllDestinations() {
        return destinationRepository.findAll();
    }

    /**
     * Get a single destination by its ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Destination> getDestinationById(@PathVariable Long id) {
        Optional<Destination> destination = destinationRepository.findById(id);
        return destination.map(ResponseEntity::ok)
                          .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Create a new destination.
     */
    @PostMapping
    public ResponseEntity<Destination> createDestination(@RequestBody Destination destination) {
        Destination savedDestination = destinationRepository.save(destination);
        return ResponseEntity.ok(savedDestination);
    }

    /**
     * Update an existing destination by ID.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Destination> updateDestination(@PathVariable Long id, @RequestBody Destination updatedDestination) {
        Optional<Destination> existing = destinationRepository.findById(id);
        if (existing.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Destination destination = existing.get();
        destination.setName(updatedDestination.getName());
        destination.setCity(updatedDestination.getCity());
        destination.setCountry(updatedDestination.getCountry());
        destination.setDescription(updatedDestination.getDescription());
        destination.setImageUrl(updatedDestination.getImageUrl());
        destination.setEstimatedDailyBudget(updatedDestination.getEstimatedDailyBudget());

        Destination savedDestination = destinationRepository.save(destination);
        return ResponseEntity.ok(savedDestination);
    }

    /**
     * Delete a destination by ID.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDestination(@PathVariable Long id) {
        if (!destinationRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        destinationRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Find a destination by its name.
     */
    @GetMapping("/search")
    public ResponseEntity<Destination> findByName(@RequestParam String name) {
        Optional<Destination> destination = destinationRepository.findByNameIgnoreCase(name);
        return destination.map(ResponseEntity::ok)
                          .orElse(ResponseEntity.notFound().build());
    }
}
