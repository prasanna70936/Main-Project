document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const name = params.get("name");
  const address = params.get("address");
  const amount = params.get("amount");
  const rating = params.get("rating");

  const detailsDiv = document.getElementById("details");
  detailsDiv.innerHTML = `
    <strong>Hotel:</strong> ${name}<br>
    <strong>Address:</strong> ${address}<br>
    <strong>Rating:</strong> ${rating}/5<br>
    <strong>Amount:</strong> ₹${amount}
  `;

  document.getElementById("payBtn").addEventListener("click", () => makePayment(amount, name));
  document.getElementById("refundBtn").addEventListener("click", () => refundPayment());
});

function makePayment(amount, hotelName) {
  fetch(`http://localhost:9097/api/stripe/make-payment?amount=${amount}`, {
    method: "POST"
  })
    .then(res => res.json())
    .then(data => {
      if (data.paymentId) {
        alert(`✅ Payment successful!\n🏨 Hotel: ${hotelName}\n💰 Amount: ₹${data.amount / 100}\n💳 Payment ID: ${data.paymentId}`);
      } else {
        alert("❌ Payment failed: " + JSON.stringify(data));
      }
    })
    .catch(err => {
      console.error("Payment error:", err);
      alert("Error during payment. Check console.");
    });
}

function refundPayment() {
  const paymentIntentId = prompt("Enter the Payment ID to refund:");
  if (!paymentIntentId) {
    alert("Refund cancelled. No Payment ID provided.");
    return;
  }

  fetch(`http://localhost:9097/api/stripe/refund?paymentIntentId=${paymentIntentId}`, {
    method: "POST"
  })
    .then(res => res.json())
    .then(data => {
      if (data.message) {
        alert(`💸 ${data.message}`);
      } else {
        alert("❌ Refund failed: " + JSON.stringify(data));
      }
    })
    .catch(err => {
      console.error("Refund error:", err);
      alert("Error during refund. Check console.");
    });
}
