document.getElementById("signupForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  console.log("✅ Signup form submitted");

  const form = e.target;
  const data = {
    name: form.name.value,
    email: form.email.value,
    password: form.password.value,
    role: form.role.value,
  };
  console.log("📤 Data to send:", data);

  try {
    const response = await fetch("http://localhost:9097/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    console.log("📥 Response status:", response.status);

    if (response.ok) {
      alert("✅ Signup successful!");
      window.location.href = "login.html";
    } else {
      const errorText = await response.text();
      console.log("❌ Server responded with error:", errorText);
      alert("❌ Signup failed: " + errorText);
    }
  } catch (error) {
    console.error("❌ Fetch error:", error);
    alert("❌ Signup failed: Could not connect to server");
  }
});
