document.addEventListener("DOMContentLoaded", () => {
  const trip = JSON.parse(sessionStorage.getItem("tripData"));
  if (!trip) {
    document.getElementById("tripDetails").innerHTML = "<p>No trip data found. Please plan a trip first.</p>";
    return;
  }

  const container = document.getElementById("tripDetails");
  container.innerHTML = `
    <p><strong>Trip ID:</strong> ${trip.tripId}</p>
    <p><strong>Places:</strong> ${trip.places.join(", ")}</p>
    <p><strong>Estimated Budget:</strong> ₹${trip.estimatedBudget}</p>
    <p><strong>Weather:</strong> ${trip.weather}</p>
    <ul>${trip.dayWiseItinerary.map(day => `<li>${day}</li>`).join("")}</ul>
    <div class="button-group">
      <button onclick="downloadPdf()">Download PDF</button>
      <button onclick="findHotels()">Nearby Hotels</button>
    </div>
  `;
});

async function downloadPdf() {
  const trip = JSON.parse(sessionStorage.getItem("tripData"));
  try {
    const res = await fetch("http://localhost:9097/api/trips/download-pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(trip),
    });

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "itinerary.pdf";
    a.click();
    URL.revokeObjectURL(url);

  } catch (err) {
    console.error(err);
    alert("Could not download PDF: " + err.message);
  }
}
function findHotels() {
  const trip = JSON.parse(sessionStorage.getItem("tripData"));
  if (!trip || !trip.places || !trip.places.length) {
    alert("No trip destination found to search hotels around.");
    return;
  }

  alert("Search for nearby hotels around: " + trip.places.join(", "));

  // Save the first destination place so hotel.html can use it automatically
  sessionStorage.setItem("hotelSearchLocation", trip.places[0]);

  // Redirect to hotel.html
  window.location.href = "hotel.html";
}
function openMap() {
      const trip = JSON.parse(sessionStorage.getItem("tripData"));
      if (!trip) {
        alert("Trip data not found!");
        return;
      }
      window.location.href = `map.html?location=${encodeURIComponent(trip.places[0])}`;
    }

