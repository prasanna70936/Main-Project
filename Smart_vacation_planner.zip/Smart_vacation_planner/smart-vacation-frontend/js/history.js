document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("history-container");

  const userEmail = localStorage.getItem("userEmail");
  if (!userEmail) {
    container.innerHTML = `<p class="error-message">❌ User email not found. Please log in first.</p>`;
    return;
  }

  try {
    const encodedEmail = encodeURIComponent(userEmail);
    const response = await fetch(`http://localhost:9097/api/trips/history/by-email/${encodedEmail}`);
    if (!response.ok) throw new Error(`Server returned ${response.status}`);

    const trips = await response.json();
    container.innerHTML = ""; // clear loading message

    if (!trips.length) {
      container.innerHTML = `<p class="error-message">😕 No trips found in your history.</p>`;
      return;
    }

    trips.forEach(trip => {
      const card = document.createElement("div");
      card.className = "trip-card";
      card.innerHTML = `
        <h3>Trip #${trip.tripId}</h3>
        <p><strong>Places:</strong> ${trip.places.join(", ")}</p>
        <p><strong>Estimated Budget:</strong> ₹${trip.estimatedBudget.toLocaleString()}</p>
        <p><strong>Weather:</strong> ${trip.weather}</p>
        <h4>Day-wise Itinerary:</h4>
        <ul class="itinerary-list">
          ${trip.dayWiseItinerary.map(item => `<li>${item}</li>`).join("")}
        </ul>
      `;
      container.appendChild(card);
    });
  } catch (err) {
    console.error("❌ Error fetching trip history:", err);
    container.innerHTML = `<p class="error-message">❌ Could not load trip history. Please try again later.</p>`;
  }
});
