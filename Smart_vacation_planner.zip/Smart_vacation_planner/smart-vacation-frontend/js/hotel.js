const GEOAPIFY_KEY = "d63935835b854340a63040c527d84f8b";

document.addEventListener("DOMContentLoaded", () => {
  const location = sessionStorage.getItem("hotelSearchLocation");
  if (!location) {
    document.getElementById("results").innerHTML = "<p>No destination found. Please plan a trip first.</p>";
    return;
  }
  searchHotels(location);
});

function searchHotels(location) {
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = `<p>Loading hotels for "${location}"...</p>`;

  fetch(`https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(location)}&apiKey=${GEOAPIFY_KEY}`)
    .then(res => res.json())
    .then(data => {
      if (!data.features.length) {
        resultsDiv.innerHTML = `<p>No results found for "${location}"</p>`;
        return;
      }

      const { lat, lon } = data.features[0].properties;
      const hotelURL = `https://api.geoapify.com/v2/places?categories=accommodation.hotel&filter=circle:${lon},${lat},5000&limit=10&apiKey=${GEOAPIFY_KEY}`;

      fetch(hotelURL)
        .then(res => res.json())
        .then(data => {
          resultsDiv.innerHTML = "";
          const hotels = data.features;
          if (!hotels.length) {
            resultsDiv.innerHTML = `<p>No hotels found near "${location}"</p>`;
            return;
          }

          hotels.forEach(hotel => {
            const name = hotel.properties.name || "Unnamed Hotel";
            const address = hotel.properties.formatted || "No address available";
            const rating = getRandomRating();
            const amount = getRandomAmount(1000, 5000);

            const div = document.createElement("div");
            div.className = "hotel";
            div.innerHTML = `
              <strong>${name}</strong><br>
              📍 ${address}<br>
              ⭐ Rating: ${rating} / 5<br>
              💰 Payment: ₹${amount}<br>
              <button class="action-btn book-btn" onclick="bookHotel('${escapeQuotes(name)}', '${escapeQuotes(address)}', ${amount}, ${rating}, this)">Book Now</button>
            `;
            resultsDiv.appendChild(div);
          });
        })
        .catch(err => {
          console.error("Error fetching hotel data:", err);
          resultsDiv.innerHTML = "<p>Error loading hotels. Please try again later.</p>";
        });
    })
    .catch(err => {
      console.error("Error fetching location data:", err);
      resultsDiv.innerHTML = "<p>Error finding location. Please check your input.</p>";
    });
}

function bookHotel(name, address, amount, rating, btn) {
  alert(`✅ Booking confirmed for:\n🏨 ${name}\n📍 ${address}\n⭐ ${rating}/5\n💰 ₹${amount}`);
  const parent = btn.parentNode;
  parent.innerHTML += `
    <button class="action-btn cancel-btn" onclick="cancelBooking('${escapeQuotes(name)}')">Cancel</button>
    <button class="action-btn refund-btn" onclick="refundBooking('${escapeQuotes(name)}', ${amount})">Refund</button>
  `;
  btn.remove();
}

function cancelBooking(name) {
  alert(`❌ Booking cancelled for ${name}`);
}

function refundBooking(name, amount) {
  alert(`💸 Refund of ₹${amount} initiated for ${name}`);
}

function escapeQuotes(str) {
  return str.replace(/'/g, "\\'").replace(/"/g, '\\"');
}

function getRandomAmount(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRandomRating() {
  return (Math.random() * 2 + 3).toFixed(1); // Between 3.0 and 5.0
}
function bookHotel(name, address, amount, rating, btn) {
  const params = new URLSearchParams({
    name: name,
    address: address,
    amount: amount,
    rating: rating,
  });
  window.location.href = `payment.html?${params.toString()}`;
}
