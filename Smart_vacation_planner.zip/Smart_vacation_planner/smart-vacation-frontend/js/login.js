// login.js
document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const params = new URLSearchParams();
  params.append("email", form.email.value);
  params.append("password", form.password.value);

  const response = await fetch("http://localhost:9097/api/auth/login?" + params, {
    method: "POST",
  });

  if (response.ok) {
    // ✅ store the logged-in email for later history fetch
    localStorage.setItem("userEmail", form.email.value);
    alert("Login successful!");
    window.location.href = "dashboard.html";
  } else {
    alert("Invalid credentials!");
  }
});
