document.getElementById("feedbackForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const statusEl = document.getElementById("feedbackStatus");
  statusEl.style.color = "green";
  statusEl.textContent = "✅ Feedback submitted successfully!";
  e.target.reset();
});
