// dashboard.js

const BACKEND_URL = "http://localhost:9097"; // ✓ Use your correct backend address

async function performSearch() {
  const query = document.getElementById("searchInput").value.trim();
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "";

  if (!query) {
    alert("Please enter a destination name!");
    return;
  }

  console.log("🔎 Searching for:", query);

  try {
    const response = await fetch(
      `${BACKEND_URL}/api/destinations/search?name=${encodeURIComponent(query)}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
      }
    );

    if (response.ok) {
      const data = await response.json();
      console.log("✅ Data received:", data);

      // Handle list or single object
      const list = Array.isArray(data) ? data : [data];
      list.forEach(dest => {
        const el = document.createElement("div");
        el.className = "result-item";
        el.innerHTML = `
          <h3>${dest.name} (${dest.city}, ${dest.country})</h3>
          <p>${dest.description}</p>
          <p><strong>Budget:</strong> ₹${dest.estimatedDailyBudget}</p>
        `;
        resultsDiv.appendChild(el);
      });

    } else if (response.status === 404) {
      console.warn("❌ No results found");
      resultsDiv.innerHTML = `<p class="no-results">No destination found for "${query}".</p>`;
    } else if (response.status === 401) {
      alert("🔒 Unauthorized. Check your login credentials or token.");
    } else {
      const error = await response.text();
      console.error("❌ Server responded with an error:", error);
      alert("Error: " + error);
    }

  } catch (err) {
    console.error("🚨 Fetch failed:", err);
    alert("Search failed. Could not connect to server.");
  }
}

// Slider functionality (existing)
let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const totalSlides = slides.length;

function showSlide(index) {
  slides.forEach((s, i) => s.classList.toggle('active', i === index));
}

setInterval(() => {
  currentSlide = (currentSlide + 1) % totalSlides;
  showSlide(currentSlide);
}, 5000);

showSlide(currentSlide);

// ─── Logout Handler ──────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("userEmail");
      localStorage.removeItem("userId");
      window.location.href = "login.html";
    });
  } else {
    console.error("Logout button not found!");
  }
});
