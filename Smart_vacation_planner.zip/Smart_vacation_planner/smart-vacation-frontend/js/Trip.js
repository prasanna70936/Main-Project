async function planTrip() {
  const data = {
    userId: parseInt(document.getElementById("userId").value, 10),
    userEmail: document.getElementById("userEmail").value.trim(),
    places: [document.getElementById("destination").value.trim()],
    startDate: document.getElementById("startDate").value,
    endDate: document.getElementById("endDate").value,
    numPeople: parseInt(document.getElementById("numPeople").value, 10),
    estimatedBudget: parseFloat(document.getElementById("budget").value),
  };

  if (Object.values(data).some(v => v === "" || v === undefined || Number.isNaN(v))) {
    alert("Please complete all fields.");
    return;
  }

  try {
    const res = await fetch("http://localhost:9097/api/trips/plan", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(data)
    });

    if (!res.ok) throw new Error(`Error ${res.status}`);

    const trip = await res.json();
    sessionStorage.setItem("tripData", JSON.stringify(trip));

    alert("✅ Email sent successfully!");

    window.location.href = "Details.html";

  } catch (err) {
    console.error(err);
    alert("Trip planning failed: " + err.message);
  }
}