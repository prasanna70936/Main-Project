document.getElementById("helpForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const statusEl = document.getElementById("helpStatus");
  statusEl.style.color = "green";
  statusEl.textContent = "✅ Your query has been submitted!";
  e.target.reset();
});
